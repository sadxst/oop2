namespace ООП_ЛР2_вар7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                int[] A = textBox1.Text
               .Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries)
               .Select(int.Parse)
               .ToArray();
                if (A.Length != 20)
                {
                    MessageBox.Show("Введіть 20 чисел через пробіл.");
                    return;
                }
                int sum = SumPositiveRecursive(A, 0);
                suma.Text = "Сума додатніх елементів: " + sum;
            }
            catch
            {
                MessageBox.Show("Помилка!");
            }
        }
        private int SumPositiveRecursive(int[] arr, int index)
        {
            if (index >= arr.Length)
                return 0;

            if (arr[index] > 0)
                return arr[index] + SumPositiveRecursive(arr, index + 1);
            else
                return SumPositiveRecursive(arr, index + 1);
        }
    }
}