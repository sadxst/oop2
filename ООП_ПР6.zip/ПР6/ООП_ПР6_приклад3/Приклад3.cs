﻿using System;

class Program
{
    static string Reverse(string s)
    {
        if (string.IsNullOrEmpty(s))
        {
            return s;
        }
        return Reverse(s.Substring(1)) + s[0].ToString();
    }

    static void Main(string[] args)
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;

        Console.Write("Введіть рядок: ");
        var inputText = Console.ReadLine();
        Console.WriteLine("Перевернутий рядок: " + Reverse(inputText));
        Console.ReadLine();
    }
}